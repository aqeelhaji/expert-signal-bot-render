import time
import threading
from keep_alive import keep_alive
from eurusd_module import run_eurusd
from gold_module import run_gold
from status_report import start_status_report

keep_alive()

threading.Thread(target=run_eurusd).start()
threading.Thread(target=run_gold).start()
threading.Thread(target=start_status_report).start()